# mypackage
This library was created for the sole purpose of practicing a good way to create a python package.

## building this package locally
'python setup.py sdist'
